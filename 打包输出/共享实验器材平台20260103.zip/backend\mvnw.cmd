@REM Maven Wrapper startup script for Windows
@REM This allows you to run Maven without having Maven installed

@echo off
setlocal

set MAVEN_PROJECTBASEDIR=%~dp0
set MAVEN_WRAPPER_VERSION=3.2.0
set MAVEN_WRAPPER_JAR=%MAVEN_PROJECTBASEDIR%.mvn\wrapper\maven-wrapper.jar
set MAVEN_WRAPPER_PROPERTIES=%MAVEN_PROJECTBASEDIR%.mvn\wrapper\maven-wrapper.properties
set DOWNLOAD_URL=https://repo.maven.apache.org/maven2/org/apache/maven/wrapper/maven-wrapper/3.2.0/maven-wrapper-3.2.0.jar

if not exist "%MAVEN_PROJECTBASEDIR%.mvn\wrapper" (
    mkdir "%MAVEN_PROJECTBASEDIR%.mvn\wrapper"
)

if not exist "%MAVEN_WRAPPER_JAR%" (
    echo Downloading Maven Wrapper...
    powershell -ExecutionPolicy Bypass -Command "& {[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -Uri '%DOWNLOAD_URL%' -OutFile '%MAVEN_WRAPPER_JAR%' } catch { Write-Host 'Download failed. Please check your internet connection.'; exit 1 }}"
    if errorlevel 1 (
        echo Failed to download Maven Wrapper
        echo Please download manually from: %DOWNLOAD_URL%
        echo And place it at: %MAVEN_WRAPPER_JAR%
        pause
        exit /b 1
    )
)

if not exist "%MAVEN_WRAPPER_JAR%" (
    echo Maven Wrapper JAR not found at: %MAVEN_WRAPPER_JAR%
    pause
    exit /b 1
)

java -cp "%MAVEN_WRAPPER_JAR%" org.apache.maven.wrapper.MavenWrapperMain %*
