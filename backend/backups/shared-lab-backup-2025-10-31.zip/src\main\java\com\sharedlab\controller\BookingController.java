package com.sharedlab.controller;

import com.sharedlab.exception.BookingConflictException;
import com.sharedlab.model.dto.BookingRequest;
import com.sharedlab.model.entity.Booking;
import com.sharedlab.service.BookingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/bookings")
@RequiredArgsConstructor
@CrossOrigin
public class BookingController {
    
    private final BookingService bookingService;
    
    /**
     * 创建预约
     */
    @PostMapping
    public ResponseEntity<?> createBooking(
            @Valid @RequestBody BookingRequest request,
            Authentication authentication
    ) {
        try {
            String username = authentication.getName();
            Booking booking = bookingService.createBooking(request, username);
            return ResponseEntity.ok(booking);
            
        } catch (BookingConflictException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.status(409).body(error);
            
        } catch (IllegalArgumentException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    /**
     * 获取当前用户的预约列表
     */
    @GetMapping("/my")
    public ResponseEntity<List<Booking>> getMyBookings(Authentication authentication) {
        String username = authentication.getName();
        List<Booking> bookings = bookingService.getUserBookings(username);
        return ResponseEntity.ok(bookings);
    }
    
    /**
     * 获取设备的预约列表（用于日历显示）
     */
    @GetMapping
    public ResponseEntity<List<Booking>> getDeviceBookings(
            @RequestParam Long deviceId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startTime,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endTime
    ) {
        if (startTime != null && endTime != null) {
            List<Booking> bookings = bookingService.getDeviceBookingsInRange(deviceId, startTime, endTime);
            return ResponseEntity.ok(bookings);
        } else {
            List<Booking> bookings = bookingService.getDeviceBookings(deviceId);
            return ResponseEntity.ok(bookings);
        }
    }
    
    /**
     * 取消预约
     */
    @PutMapping("/{id}/cancel")
    public ResponseEntity<?> cancelBooking(
            @PathVariable Long id,
            Authentication authentication
    ) {
        try {
            String username = authentication.getName();
            Booking booking = bookingService.cancelBooking(id, username);
            return ResponseEntity.ok(booking);
            
        } catch (IllegalArgumentException e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", e.getMessage());
            return ResponseEntity.badRequest().body(error);
        }
    }
    
    /**
     * 获取所有预约（仅管理员）
     */
    @GetMapping("/all")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<Booking>> getAllBookings() {
        List<Booking> bookings = bookingService.getAllBookings();
        return ResponseEntity.ok(bookings);
    }
}
