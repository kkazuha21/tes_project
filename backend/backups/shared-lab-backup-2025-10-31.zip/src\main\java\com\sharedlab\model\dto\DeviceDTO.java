package main.java.com.sharedlab.model.dto;

import com.sharedlab.model.enums.DeviceStatus;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeviceDTO {
    private Long id;
    private String name;
    private DeviceStatus status;
    private String location;
    private String description;
    private Long categoryId;
    private String categoryName;
}
