package com.sharedlab.controller;

import com.sharedlab.model.dto.TicketSubmit;
import com.sharedlab.model.entity.Ticket;
import com.sharedlab.model.enums.TicketStatus;
import com.sharedlab.service.TicketService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tickets")
@RequiredArgsConstructor
@CrossOrigin
public class TicketController {
    
    private final TicketService ticketService;
    
    /**
     * 提交报修单
     */
    @PostMapping
    public ResponseEntity<Ticket> createTicket(
            @Valid @RequestBody TicketSubmit request,
            Authentication authentication
    ) {
        String username = authentication.getName();
        Ticket ticket = ticketService.createTicket(request, username);
        return ResponseEntity.ok(ticket);
    }
    
    /**
     * 获取当前用户的报修单
     */
    @GetMapping("/my")
    public ResponseEntity<List<Ticket>> getMyTickets(Authentication authentication) {
        String username = authentication.getName();
        List<Ticket> tickets = ticketService.getUserTickets(username);
        return ResponseEntity.ok(tickets);
    }
    
    /**
     * 获取所有报修单（仅管理员）
     */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<Ticket>> getAllTickets() {
        List<Ticket> tickets = ticketService.getAllTickets();
        return ResponseEntity.ok(tickets);
    }
    
    /**
     * 获取报修单详情
     */
    @GetMapping("/{id}")
    public ResponseEntity<Ticket> getTicketById(@PathVariable Long id) {
        Ticket ticket = ticketService.getTicketById(id);
        return ResponseEntity.ok(ticket);
    }
    
    /**
     * 更新报修单状态（仅管理员）
     */
    @PutMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Ticket> updateTicketStatus(
            @PathVariable Long id,
            @RequestParam TicketStatus status
    ) {
        Ticket ticket = ticketService.updateTicketStatus(id, status);
        return ResponseEntity.ok(ticket);
    }
}
