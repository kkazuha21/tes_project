package com.sharedlab.repository;

import com.sharedlab.model.entity.Ticket;
import com.sharedlab.model.enums.TicketStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {
    
    List<Ticket> findByUserId(Long userId);
    
    List<Ticket> findByDeviceId(Long deviceId);
    
    List<Ticket> findByStatus(TicketStatus status);
    
    List<Ticket> findAllByOrderByCreatedAtDesc();
}
